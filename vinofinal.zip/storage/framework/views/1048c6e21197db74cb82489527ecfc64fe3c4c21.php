<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

        <!-- Styles -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    </head>
    <body>
       <div id="root"></div>
    </body>
</html>
<?php /**PATH C:\xamppp\htdocs\ete2022\projet-web-2\vino-main-5\vino-main\resources\views/welcome.blade.php ENDPATH**/ ?>