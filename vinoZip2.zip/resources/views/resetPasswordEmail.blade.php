<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="utf-8">
    <title></title>
</head>
<body>
Salut <strong>{{ $name }}</strong>,
<p>La demande de réinitialisation de mot de passe a bien été prise en compte. Clique sur le lien ci-dessous pour entrer ton nouveau mot de passe.</p>
<p>{!!$body!!}</p>
</body>
</html>