<<<<<<< HEAD

# vino

# projet web 2 équipe Catherine Romain Jaouad &amp; Mounir

> > git : https://github.com/MounirBHK/vino

> > url : https://mounirbhk.ca

Identifiants user:

-   user@vino.com
-   aaaaaaA1

Identifiants super admin:

-   admin@admin.com
-   Administrator1

> > REACT-LARAVEL consignes

Il est important de copier le fichier .env.exemple et le nommer .env

Dans le fichier .env verifier les accès à la base de données

et d'executer ces commandes:

-   pour les nodes modules
    -:- npm install
-   mise à jour de composer
    -:- composer update
-   Pour la génération des clès laravel
    -:- php artisan key:generate
-   Démarrer
    -:- npm run watch
-   Démarrer
    -:- php artisan serve

mxwkkxbbpttdcjuk
